#Comando a usar en el VPS:

```
 cd /standalone && node sserver.js
```
